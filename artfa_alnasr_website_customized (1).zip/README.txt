ARTFA ALNASR TRADING & CONTRACTING — CUSTOMIZED STARTER WEBSITE

Website domain: https://irthifaalnasr.com
Phone / WhatsApp: +974 3395 1318
Email: info@irthifaalnasr.com
Languages: English and Arabic

Included:
- index.html: responsive bilingual English/Arabic website
- English/Arabic language switch and right-to-left Arabic layout
- Services, About, Projects, and Contact sections
- Tap-to-call, email, and WhatsApp contact links

BEFORE PUBLISHING:
1. Replace the temporary "AA" text mark with your existing logo image.
2. Add genuine project photos and company profile information.
3. Check that the phone, WhatsApp, and email links work.
4. Review all descriptions and ensure they match your actual services.

FREE HOSTING OPTION:
GitHub Pages can host a static HTML website for free from a public repository on GitHub Free. Domain renewal may still cost money.
Publishing steps:
1. Sign in or create a GitHub account.
2. Create a new PUBLIC repository named artfa-alnasr-website.
3. Upload index.html to the repository root.
4. Open repository Settings > Pages.
5. Set the publishing source to Deploy from a branch, choose main and /(root), then Save.
6. After GitHub provides the site's default URL, go to Settings > Pages > Custom domain and enter irthifaalnasr.com. Save.
7. In the domain provider's DNS panel, configure GitHub Pages DNS records. For the apex/root domain, GitHub documents A records:
   185.199.108.153
   185.199.109.153
   185.199.110.153
   185.199.111.153
   For www, add a CNAME pointing to YOUR-GITHUB-USERNAME.github.io.
   Replace YOUR-GITHUB-USERNAME with the exact GitHub username. Do not change DNS until you know which service currently handles the domain and have recorded existing DNS/email records.
8. Once DNS is configured, return to Settings > Pages and enable Enforce HTTPS when the option becomes available.
DNS changes can take up to 24 hours to propagate.

Important: keep any existing MX records for company email unchanged. If you already use email at this domain, changing DNS incorrectly can interrupt email.
